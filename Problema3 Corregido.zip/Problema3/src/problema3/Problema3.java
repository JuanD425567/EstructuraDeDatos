package problema3;
import java.util.Scanner;
public class Problema3 {
    
    public static void main(String[] args) {
       Fibonacci f = new Fibonacci(); 
       Scanner entrada = new Scanner(System.in);
       
        System.out.println("Ingrese el tamaño del arreglo");
        int[] A= new int[entrada.nextInt()]; 
        for (int i = 0; i < A.length; i++) {
            A[i]=i;
        }
        f.setA(A);
        f.Fibonaccil();
    }
}
