package problema3;

public class Fibonacci {

    int[] A;
    
    public void Fibonaccil() {
        int[] B = new int[A.length];
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A[i]; j++) {
                B[i]=Fibo(A[i]);
            }
        }
        System.out.println("--------------------------------------------------");
        for (int i = 0; i < A.length; i++) {
            System.out.println("El fibonacci de " + A[i] + " es " + B[i]);
        }
        System.out.println("---------------------------------------------------");
    }
    public int Fibo(int n){
        if (n==0) {
            return 0;
        }
        if (n==1) {
            return 1;
        }else
            return Fibo(n-1)+Fibo(n-2);
        
    }
    
    public int[] getA() {
        return A;
    }

    public void setA(int[] A) {
        this.A = A;
    }

}
