/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package intento;

/**
 *
 * @author SALA H
 */
public class Intento {
    public static void main(String[] args) {
        Metodos m = new Metodos();
        int[][] A = new int[2][3];
        int[][] B = new int[3][4];
        int[][] C = new int[2][4];
        
        int opcion = m.menu();
        
        System.out.println(opcion);
        
        switch(opcion){
            case 3 -> m.llenar(A);
            case 4 -> m.presenta(A);
            case 5 -> m.determinante(A);
        }
    }
    
}
