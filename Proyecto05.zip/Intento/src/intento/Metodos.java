 package intento;

import java.util.Scanner;

public class Metodos {

    Scanner entrada = new Scanner(System.in);

    public int menu() {
        System.out.println("Transponer superior [0]");
        System.out.println("Transponer inferior [1]");
        System.out.println("Multiplicar [2]");
        System.out.println("Llenar arreglo [3]");
        System.out.println("Presentar [4]");
        System.out.println("Determinante [5]");
        return entrada.nextInt();
    }

    public void llenar(int[][] X) {
        for (int i = 0; i < X.length; i++) {
            for (int j = 0; j < X[0].length; j++) {
                System.out.println("Ingrese el valor para posicion[" + i + "] "
                        + "[" + j + "]");
                X[i][j] = entrada.nextInt();
            }
        }
    }

    public void presenta(int[][] X) {
        for (int i = 0; i < X.length; i++) {
            for (int j = 0; j < X[0].length; j++) {
                System.out.println(X[i][j] + "\t");
            }
            System.out.println("");
        }
    }

    public void multMat(int[][] A,int[][]B,int[][]C) {
        
    }
    //DEMASIADO DEMASIADO DE VERDAD ES DEMASIADO IMPORTANTE.
    public int determinante(int[][]X){
        //Aclumulador de multiplicacion
        int am1;
        int am2;
        //Determinante
        int d;
        //Acumuladores de sumas
        int as1 = 0;
        int as2 = 0;
        //Auxiliares del ciclo for
        int k;
        int l;
        for (int i = 0; i < X.length; i++) {
            k =i;
            l=X.length-1-i;
            am1=1;
            am2=1;
            for (int j = 0; j < X.length; j++) {
                am1=am1*X[j][k];
                am2=am2*X[j][l];
                if (k==X.length-1) {
                    k=0;
                    l=3;
                }else{
                    k++;
                    l--;        
                }
            }
            as1=as1+am1;
            as2=as2+am2;
        }
        d=as1-as2;
        
        return d;
    }
}
