package programa.pkg1;

import java.util.Scanner;

public class Proceso {

    Scanner entrada = new Scanner(System.in);
    int n;
    
    public void Menu() {
        System.out.println("Ingrese el valor de N");
        n = entrada.nextInt();
        int[][] A = new int[n][n];
        int[][]R = new int[n][n];
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A[i].length; j++) {
                System.out.println("Ingrese el valor de: " + "[" + i + "] "
                        + "[" + j + "]");
                A[i][j] = entrada.nextInt();
            }
        }
      
        Multiplicacion(A,R, Fibonaci(n));
    }

    public int Fibonaci(int n) {
        if (n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        } else {
            return Fibonaci(n - 1) + Fibonaci(n - 2);
        }
        
    }

    public void Multiplicacion(int[][]A, int [][]R, int n) {
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A[i].length; j++) {
                R[i][j]=A[i][j]*n;
            }
        }
        Pantalla(R,A);
    }
    
    public void Pantalla(int[][]R, int[][]A){
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < A[i].length; j++) {
                System.out.println("----------------------------------------");
                System.out.println("La multiplicacion de A * N(Fibonacci)");
                System.out.println(A[i][j]+"multiplicado por N"
                        + "(Fibonacci) es: "+R[i][j]);
            }
        }
    }
}
