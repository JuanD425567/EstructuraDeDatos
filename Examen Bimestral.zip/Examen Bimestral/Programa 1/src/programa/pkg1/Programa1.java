package programa.pkg1;

import java.util.Scanner;

public class Programa1 {

    public static void main(String[] args) {
        Proceso p = new Proceso();
        p.Menu();
    }
    
}
