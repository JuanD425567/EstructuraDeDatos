package programa.pkg2;

import java.util.Scanner;

public class Interseccion {

    Scanner entrada = new Scanner(System.in);

    public void Datos() {
        System.out.println("Ingrese el tamaño del arreglo A");
        int[] A = new int[entrada.nextInt()];
        System.out.println("Ingrese el tamaño del arreglo B");
        int[] B = new int[entrada.nextInt()];

        for (int i = 0; i < A.length; i++) {
            System.out.println("Ingrese el valor de A en la posición " + "[" + i + "]");
            int v1 = entrada.nextInt();

            int indice = BusquedaSecuencial(A, v1);
            if (indice != -1) {
                System.out.println("El valor ya existe en el arreglo A. Ingrese otro valor.");
                i--;
            } else {
                A[i] = v1;
            }
        }

        for (int i = 0; i < B.length; i++) {
            System.out.println("Ingrese el valor de B en la posición " + "[" + i + "]");
            int v2 = entrada.nextInt();

            int indice = BusquedaSecuencial(B, v2);
            if (indice != -1) {
                System.out.println("El valor ya existe en el arreglo B. Ingrese otro valor.");
                i--;
            } else {
                B[i] = v2;
            }
        }

        Interseccion(A, B);
    }

    public void Interseccion(int[] A, int[] B) {
        int tamañoC = Math.max(A.length, B.length);
        int[] C = new int[tamañoC];
        int contador = 0;

        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < B.length; j++) {
                if (A[i] == B[j]) {
                    C[contador] = A[i];
                    contador++;
                    break;
                }
            }
        }

        Pantalla(C, contador);

    }

    public void Pantalla(int[] C, int contador) {
        for (int i = 0; i < contador; i++) {
            System.out.println(C[i]);
        }
    }

    public static int BusquedaSecuencial(int[] arreglo, int elemento) {
        for (int i = 0; i < arreglo.length; i++) {
            if (arreglo[i] == elemento) {
                return i;
            }
        }
        return -1;
    }
}
